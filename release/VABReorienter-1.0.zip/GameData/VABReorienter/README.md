# VABReorienter
Simple little mod that allows choosing the default orientation of a new vessel in the VAB.
